
from __future__ import print_function
import sys
import os
from semmle import logging
from semmle import traverser
from semmle import cmdline
from semmle import worker
from semmle.util import VERSION
'The populator generates trap files from a Python project.\nThe populator consists of two parts: a traverser front end which traverses the file\nsystem and multiple worker back ends which extract information from the modules.\n'

def cleanup_sys_path(path):
    path = [p for (i, p) in enumerate(path) if ((i == 0) or (p != path[(i - 1)]))]
    cwd = os.getcwd()
    if (cwd in path):
        path.remove(cwd)
    return path

def main(sys_path=sys.path[:]):
    sys.setrecursionlimit(2000)
    sys_path = cleanup_sys_path(sys_path)
    (options, args) = cmdline.parse(sys.argv[1:], sys_path)
    logger = logging.Logger(options.verbosity, options.colorize)
    try:
        the_traverser = traverser.Traverser(options, args, logger)
    except Exception as ex:
        logger.error('%s', ex)
        logger.close()
        logging.stop()
        sys.exit(1)
    run(options, args, the_traverser, logger)

def run(options, args, the_traverser, logger):
    logger.info('Python version %s', sys.version.split()[0])
    logger.info('Python extractor version %s', VERSION)
    if ('CODEQL_EXTRACTOR_PYTHON_SOURCE_ARCHIVE_DIR' in os.environ):
        archive = os.environ['CODEQL_EXTRACTOR_PYTHON_SOURCE_ARCHIVE_DIR']
    elif ('SOURCE_ARCHIVE' in os.environ):
        archive = os.environ['SOURCE_ARCHIVE']
    else:
        archive = None
    trap_dir = cmdline.output_dir_from_options_and_env(options)
    try:
        pool = worker.ExtractorPool.from_options(options, trap_dir, archive, logger)
    except ValueError as ve:
        logger.error('%s', ve)
        logger.close()
        sys.exit(1)
    try:
        exitcode = 0
        pool.extract(the_traverser)
    except worker.ExtractorFailure:
        exitcode = 1
    except KeyboardInterrupt:
        exitcode = 2
        logger.info('Keyboard interrupt')
    except BaseException as ex:
        exitcode = 3
        logger.error('Unexpected exception: %s ', ex)
        logger.traceback(logging.WARN)
    finally:
        if exitcode:
            logger.debug('Stopping...')
            pool.stop()
        else:
            logger.debug('Writing interpreter trap')
            pool.close()
        logger.close()
        logging.stop()
        logger.write_message(logging.DEBUG, ('Stopped.' if exitcode else 'Done.'))
        if exitcode:
            sys.exit(exitcode)
if (__name__ == '__main__'):
    main()
